<?php
/**
 * Created by Bruce.
 * IDE: PhpStorm
 * Date: 2018/7/28
 * Time: 9:03
 * 账单类型
 * GetOrderMode  使用
 */

return ['停车场', '路边', '开锁'];