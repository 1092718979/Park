<?php
/**
 * Created by PhpStorm.
 * User: Bruce
 * Date: 2018/7/18
 * Time: 19:29
 *
 * 停车场类型
 * 在getAllParks中使用
 */
return ['停车场', '路边'];
