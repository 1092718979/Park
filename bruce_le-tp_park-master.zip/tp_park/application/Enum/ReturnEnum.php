<?php
/**
 * Created by JiFeng.
 * User: 10927
 * Date: 2018/5/12
 * Time: 10:59
 */

namespace app\Enum;


class ReturnEnum {

}