<?php
/**
 * Created by JiFeng.
 * User: 10927
 * Date: 2018/5/12
 * Time: 19:19
 */

namespace app\Enum;


class RoadsideEnum {
    //车位空闲
    const FREE = 1;
    //已预约
    const APPOINTMENT = 2;
    //已停车
    const PARKING = 3;
}