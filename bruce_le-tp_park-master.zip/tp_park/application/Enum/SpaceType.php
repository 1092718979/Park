<?php
/**
 * Created by Bruce.
 * IDE: PhpStorm
 * Date: 2018/7/27
 * Time: 15:45
 */
return ['usable' => 0, 'unusable' => 1];