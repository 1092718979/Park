<?php
/**
 * Created by PhpStorm.
 * User: Bruce
 * Date: 2018/4/29
 * Time: 10:09
 * 查询路边的详细信息{parkId}
 * 返回{parkId,stat:'路边/停车场',totalNum,space(空余路边车位锁号):
 */

namespace app\park\controller;


class QueryRoadsideParks
{

}