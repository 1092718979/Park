<?php
/**
 * Created by PhpStorm.
 * User: Bruce
 * Date: 2018/4/29
 * Time: 10:13
 * 9.路边开锁{openId,parkId,space,,orderId}
 * 返回{stat:'success/fail',message:''}
 */

namespace app\park\controller;


class RoadsideIsOrder
{

}