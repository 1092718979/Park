<?php
/**
 * Created by JiFeng.
 * User: 10927
 * Date: 2018/7/24
 * Time: 10:43
 */

namespace app\park\model;


use think\Model;

class BackInfo extends Model
{

}