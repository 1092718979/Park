<?php
/**
 * Created by JiFeng.
 * User: 10927
 * Date: 2018/5/20
 * Time: 18:17
 */

namespace app\park\model;


use think\Model;

class ParkInfo extends Model{

}